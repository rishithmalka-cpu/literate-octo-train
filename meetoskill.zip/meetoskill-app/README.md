# MeetoSkill

Live video skill-exchange matching for creators, entrepreneurs, editors and students. Random-but-purposeful matching (Omegle-style connect, but for trading skills), live WebRTC video + text chat, and a connection history page.

## How it works

- **Frontend**: `public/index.html` — plain HTML/CSS/JS, no build step. Profile and history are stored in the browser's `localStorage`, so the site "remembers you" on that device without any login system.
- **Backend**: `server.js` — a small Express + Socket.io server. It does **not** use a database. It only:
  1. Holds people in an in-memory waiting queue and pairs them up (preferring complementary skills).
  2. Relays WebRTC signaling (offer/answer/ICE candidates) between two matched people so their browsers can open a direct peer-to-peer video connection.
  3. Relays live text chat messages between the two matched people.

Once two people are matched, video and audio flow **directly between their browsers** (peer-to-peer) — the server is just the matchmaker and the messenger that introduces them.

## Run it locally

```bash
npm install
npm start
```

Then open **http://localhost:3000**. Open it in two different browser tabs/windows (or two devices on the same network) to test matching with yourself.

> Camera/mic access requires a "secure context." `localhost` counts as secure, so it works fine locally over plain HTTP. In production you'll need HTTPS (see below).

## Deploying to your own domain

You need a host that runs a persistent Node.js process with WebSocket support — **not** a static-file host (plain GitHub Pages, S3, etc. won't work, since this needs Socket.io's live connection).

Good options:
- **Render** (render.com) — free/low-cost Node web service, HTTPS included automatically.
- **Railway** (railway.app) — similar, very quick to deploy from a GitHub repo.
- **Fly.io** — more control, still simple.
- **A VPS** (DigitalOcean, Linode, Hetzner, etc.) — full control, but you'll need to set up HTTPS yourself (e.g. Nginx or Caddy as a reverse proxy with Let's Encrypt) and a process manager (e.g. `pm2`) to keep `server.js` running.

General steps for a platform like Render/Railway:
1. Push this folder to a GitHub repo.
2. Create a new "Web Service" and point it at the repo.
3. Build command: `npm install`. Start command: `npm start`.
4. The platform sets the `PORT` environment variable automatically — `server.js` already reads `process.env.PORT`.
5. Once deployed, point your domain's DNS at the platform (they each give you a CNAME/A record to use), and the platform issues an HTTPS certificate for you.

### Why HTTPS matters here specifically
Browsers block camera/microphone access (`getUserMedia`) on any page that isn't loaded over HTTPS (or `localhost`). If your custom domain isn't on HTTPS, the video call feature will fail with a permission/availability error, even though everything else works. Render, Railway and Fly.io all give you HTTPS automatically — if you go the VPS route, set up a reverse proxy with a free Let's Encrypt certificate.

## A note on video reliability (TURN servers)

This app uses public Google STUN servers to help two browsers find a direct path to each other. That works for most home/wifi networks. It will **not** work for everyone — some corporate networks, mobile carriers, or strict firewalls block direct peer-to-peer connections entirely. The industry-standard fix is a **TURN server**, which relays video through a third point when a direct connection isn't possible.

This project doesn't include one, since it requires its own paid/hosted service or infrastructure (e.g. a small hosted TURN service like Twilio's, Cloudflare Calls, Xirsys, or self-hosting `coturn` on a VPS). If you find video calls failing for some users specifically, that's the next thing to add — happy to help wire one in once you've got an account with a TURN provider.

## Project structure

```
meetoskill/
  server.js          ← Express + Socket.io backend
  package.json
  public/
    index.html        ← entire frontend (HTML/CSS/JS in one file)
  README.md
```

## Customizing

- **Colors**: CSS variables at the top of `public/index.html` (`--primary`, `--secondary`, `--bg`, etc).
- **Matching logic**: `tryMatch()` in `server.js` — currently prefers a partner whose offer/want overlaps yours, falling back to first-in-line.
- **Roles dropdown**: the `<select id="roleSelect">` options in `public/index.html`.
