// MeetoSkill server
// Serves the frontend and handles: matchmaking queue, WebRTC signaling relay, live chat relay.
// No database is used — profile + history live in the browser (localStorage).
// Run: npm install && npm start   (defaults to PORT 3000)

const express = require('express');
const http = require('http');
const path = require('path');
const { Server } = require('socket.io');

const app = express();
const server = http.createServer(app);
const io = new Server(server, {
  cors: { origin: '*' } // tighten this to your real domain once deployed
});

app.use(express.static(path.join(__dirname, 'public')));
app.get('/healthz', (req, res) => res.send('ok'));

// Temporary debug helper — open this URL in a browser to see live server state.
// Remove this route once matching is confirmed working, since it exposes names/skills.
app.get('/debug/queue', (req, res) => {
  res.json({
    waiting: waitingQueue.map(e => ({ name: e.profile.name, offer: e.profile.offer, want: e.profile.want, waitingSeconds: Math.round((Date.now() - e.ts) / 1000) })),
    activeConnections: io.sockets.sockets.size,
    activePairs: socketRoom.size / 2
  });
});

// ---------- in-memory matchmaking state ----------
// waitingQueue: [{ socketId, profile, ts }]
// socketProfile: socketId -> profile
// socketRoom:    socketId -> roomId
const waitingQueue = [];
const socketProfile = new Map();
const socketRoom = new Map();

function sanitizeProfile(p) {
  if (!p) return null;
  const name = String(p.name || '').trim().slice(0, 30);
  const role = String(p.role || '').trim().slice(0, 24);
  const offer = String(p.offer || '').trim().slice(0, 60);
  const want = String(p.want || '').trim().slice(0, 60);
  if (!name || !offer || !want) return null;
  return { name, role, offer, want };
}

function relates(a, b) {
  if (!a || !b) return false;
  a = a.toLowerCase(); b = b.toLowerCase();
  return a.includes(b) || b.includes(a);
}

function removeFromQueue(socketId) {
  const idx = waitingQueue.findIndex(e => e.socketId === socketId);
  if (idx !== -1) waitingQueue.splice(idx, 1);
}

// Tries to pair `socket` (with `profile`) against the waiting queue.
// Prefers a candidate whose offer/want complements this person's; falls back to first-in-line.
// Returns true if matched (and removes both from any further queueing).
function tryMatch(socket, profile) {
  if (waitingQueue.length === 0) return false;

  let bestIdx = -1, bestScore = 2;
  waitingQueue.forEach((c, i) => {
    const score = (relates(profile.want, c.profile.offer) || relates(profile.offer, c.profile.want)) ? 0 : 1;
    if (score < bestScore) { bestScore = score; bestIdx = i; }
  });
  if (bestIdx === -1) return false;

  const partnerEntry = waitingQueue.splice(bestIdx, 1)[0];
  const partnerSocket = io.sockets.sockets.get(partnerEntry.socketId);

  if (!partnerSocket || !partnerSocket.connected) {
    // stale entry (they disconnected without cleanup) — drop it and try the next best
    return tryMatch(socket, profile);
  }

  const roomId = 'room_' + Date.now() + '_' + Math.random().toString(36).slice(2, 8);
  socket.join(roomId);
  partnerSocket.join(roomId);
  socketRoom.set(socket.id, roomId);
  socketRoom.set(partnerSocket.id, roomId);

  console.log('[matched]', profile.name, '<->', partnerEntry.profile.name, 'room:', roomId);

  // the person who was already waiting becomes the WebRTC "caller"
  socket.emit('matched', { roomId, partner: partnerEntry.profile, isCaller: false });
  partnerSocket.emit('matched', { roomId, partner: profile, isCaller: true });
  return true;
}

function leaveRoom(socket, reason) {
  const roomId = socketRoom.get(socket.id);
  if (!roomId) return;
  socket.to(roomId).emit('partner-left', { reason: reason || 'left' });
  socket.leave(roomId);
  socketRoom.delete(socket.id);
}

io.on('connection', (socket) => {
  console.log('[connect]', socket.id, '— total connections:', io.sockets.sockets.size);

  socket.on('find-match', (data) => {
    const profile = sanitizeProfile(data && data.profile);
    if (!profile) {
      console.log('[find-match] rejected — invalid/incomplete profile from', socket.id, data);
      return;
    }
    console.log('[find-match]', socket.id, profile.name, '— queue size before:', waitingQueue.length);
    socketProfile.set(socket.id, profile);
    removeFromQueue(socket.id);
    const matched = tryMatch(socket, profile);
    if (!matched) {
      waitingQueue.push({ socketId: socket.id, profile, ts: Date.now() });
      console.log('[find-match] no partner yet, queued. Queue size now:', waitingQueue.length);
    } else {
      console.log('[find-match] matched immediately!');
    }
  });

  socket.on('cancel-search', () => {
    removeFromQueue(socket.id);
  });

  // ----- WebRTC signaling relay (room always has exactly the 2 matched peers) -----
  socket.on('offer', (data) => {
    const roomId = socketRoom.get(socket.id);
    if (roomId) socket.to(roomId).emit('offer', data);
  });
  socket.on('answer', (data) => {
    const roomId = socketRoom.get(socket.id);
    if (roomId) socket.to(roomId).emit('answer', data);
  });
  socket.on('ice-candidate', (data) => {
    const roomId = socketRoom.get(socket.id);
    if (roomId) socket.to(roomId).emit('ice-candidate', data);
  });

  // ----- live text chat -----
  socket.on('chat-message', (data) => {
    const roomId = socketRoom.get(socket.id);
    if (!roomId) return;
    const profile = socketProfile.get(socket.id) || {};
    const text = String((data && data.text) || '').slice(0, 500);
    if (!text) return;
    socket.to(roomId).emit('chat-message', { text, name: profile.name, ts: Date.now() });
  });

  socket.on('leave-call', (data) => {
    leaveRoom(socket, (data && data.reason) || 'left');
  });

  socket.on('disconnect', () => {
    console.log('[disconnect]', socket.id);
    removeFromQueue(socket.id);
    leaveRoom(socket, 'disconnected');
    socketProfile.delete(socket.id);
  });
});

const PORT = process.env.PORT || 3000;
server.listen(PORT, () => {
  console.log('MeetoSkill server running on port ' + PORT);
});
